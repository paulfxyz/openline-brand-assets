# Current creative review / Revision 10

Six distinct app views alternate orange and warm cream. Network dashboard is frame 5; plan selection is frame 6. No illustration-only frames remain. Android uses a neutral plan-choice headline. Native captures, sample data/FUP and claim verification remain required. Download:

https://openline-brand.fly.dev/downloads/openline-orange-series.zip

Editable sources:
https://openline-brand.fly.dev/downloads/openline-orange-series-sources.zip

Policy assessment:
https://openline-brand.fly.dev/downloads/screenshot-compliance-review.md

The archive-r03 folder is superseded. The final 43.5% app icon is unchanged. Competitor imagery is excluded.
