# Current creative review / Revision 06

Three orange options, with the original retained and non-orange directions discarded. No final series is selected. Download:

https://openline-brand.fly.dev/downloads/openline-orange-series.zip

Editable sources:
https://openline-brand.fly.dev/downloads/openline-orange-series-sources.zip

The archive-r03 folder holds superseded reference artwork, not the current selection. The final 43.5% icon remains approved. Competitor imagery is excluded from every handoff package.
