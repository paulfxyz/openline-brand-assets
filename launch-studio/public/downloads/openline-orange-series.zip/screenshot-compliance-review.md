# Openline screenshot compliance review

Checked 7 October 2026 against official Apple and Google guidance.

## Verdict: closer to the rules, not cleared for submission

All six current frames contain supplied app UI. Illustration-only frames were
removed following Paul's correction. These are still React design captures with
sample data, not verified native release captures. No store has approved them.
Meeting pixel dimensions and adding a review disclaimer do not establish compliance.

## Current sequence

1. Destination discovery, orange.
2. Purchase confirmation, warm cream.
3. eSIM setup, orange.
4. eSIM collection, warm cream.
5. Connection dashboard, orange.
6. Plan selection, warm cream.

No new signal readings, carrier affiliations or prices were invented. The
dashboard appears only once. Both platforms' last headline is “Your trip. Your kind
of plan.” instead of “For better prices.”

## Apple

Guideline 2.3.3 says screenshots “should show the app in use” and permits text
and image overlays. Replacing diagrams with relevant app captures better follows
that direction, but these design references must still match the shipped app.
([Apple App Review Guidelines, §2.3.3](https://developer.apple.com/app-store/review/guidelines/))

Guideline 2.3 requires metadata to accurately reflect the core experience.
Section 2.3.1(a) prohibits misleading promotion of unavailable services and
false prices; 2.3.7 also addresses inappropriate pricing/metadata. A dashboard's
Connected badge is not proof of superior signal, multiple Tier-1 partners or
profile replacement. Displayed plan prices do not prove lower prices or OMDM
savings. Those captions need separate launch evidence or neutral wording.
([Apple App Review Guidelines, §2.3](https://developer.apple.com/app-store/review/guidelines/))

## Google Play

Google separates mandatory asset requirements from “Highly recommended” guidance,
which affects recommendations/promotion and does not automatically invalidate
the listing. The screenshot recommendations call for actual in-app captures,
prioritizing UI in the first three, taglines occupying no more than 20% of the
image, and no price/promotional content. They also advise avoiding device imagery.
The current Android artwork uses actual supplied UI references, upright flat
app panels rather than hardware bezels, and a neutral final headline.
([Google preview assets: requirements and recommendations](https://support.google.com/googleplay/android-developer/answer/9866151?hl=en))

The binding Metadata policy separately prohibits misleading metadata, including
screenshots. Its clause expressly prohibiting price/promotional information in
title, icon and developer name must not be misquoted as a blanket mandatory
screenshot ban. Screenshot-specific price recommendations still make the neutral
Android caption the more conservative choice.
([Google Metadata policy](https://support.google.com/googleplay/android-developer/answer/9898842?hl=en))

## Remaining concrete gates

- Replace supplied React captures with accurate iOS/Android release-build captures.
- Verify all country coverage, plan prices, allowances, activation conditions,
  purchases and displayed product features against the launch catalog/build.
- Substantiate “Tier-1”, partner flexibility, replacement-profile availability
  and the value/sourcing explanation retained in description copy. The price-led
  screenshot headline is now removed on both platforms. Do not infer comparative performance from
  full status-bar bars or a Connected badge.
- The supplied price-selection UI includes “BEST VALUE” and “Unlimited data ·
  full speed · hotspot included.” Validate/correct these against fair-use terms,
  hotspot support and Play promotional guidance. These are existing design
  issues, not approved production claims.
- Verify display dimensions and supported device families; inspect taglines at
  listing size and against Play's recommended 20% area. Localize all overlay text.
- Remove internal review footers only after replacement/verification. Review
  platform-specific metadata again at actual submission time.

If network/value claims cannot be supported at launch, use factual captions
such as “Your connection, at a glance” and “Plans for your trip.” Relevant app UI
is necessary for this approach, but is not by itself proof of claim truth or
store acceptance.
