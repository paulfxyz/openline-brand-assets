# Openline store artwork: review candidates

These images are rendered from React design-reference screens, NOT the native release binaries. Keep the review footer until accurate native screenshots and all copy are approved. Mock prices/data are illustrative. No iPad/tablet set is included; native device support must first be confirmed.

Apple: https://developer.apple.com/help/app-store-connect/reference/app-information/screenshot-specifications
Google: https://support.google.com/googleplay/android-developer/answer/9866151?hl=en
