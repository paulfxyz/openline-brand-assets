# Openline submission draft sources

Run npm install, npx playwright install chromium, then npm run serve. In another terminal run npm run render. Install Pillow and a DejaVuSans font, then run python scripts/package_submission.py to package. Replace public/assets captures with real release-build screens, update public/submission.json and re-render before approval. Create public/downloads before packaging standalone sources. These are not approved submissions.
