# Openline complete mobile launch resources

Current iPhone and Android screenshot designs, approved icon formats, native icon
resources, editable screenshot sources, store copy, settings, checklist and policies.
The icon choice is final; screenshots and feature graphic are review candidates.

Both platforms end with “Your trip. Your kind of plan.” The network dashboard
is fifth. Backgrounds alternate orange and warm cream. All six app views are
supplied React design captures, not verified native release captures.

No competitor imagery, superseded screenshot series, credentials, signed app
binaries or native app source code is included. This is the complete current
mobile launch resource bundle, not an archive of the entire brand repository.
Read handoff/screenshot-compliance-review.md before any store submission.

Live previews: https://openline-brand.fly.dev
iPhone: https://openline-brand.fly.dev/#iphone
Android: https://openline-brand.fly.dev/#android
App Store: https://openline-brand.fly.dev/#app-store
Google Play: https://openline-brand.fly.dev/#google-play
